a ='Вторник'
print(len(a)) # end resolve 1
first = 21
second = 5
summa = first + second
diff = first - second
print(summa , diff) # end resolve 2
first = 10
second = 11
third = 5
mean = (first + second + third) / 3
print (mean) #end resolve 3
first_string ="Вторник"
second_string ="Понедельник"
print(second_string+', '+first_string) #end resolve 4
a = 1
b = 5
c = 2
f = (((a*b)+(a*c))**3)/2
print(f) # end resolve 5





